using System;
using com.aluno.veiculos.entidades.veiculo;
using com.aluno.veiculos.entidades.servicos;

namespace com.aluno.veiculos.entidades.carros
{
    public class Sedan : Carro
    {
        // Private attribute
        private bool portaMalaGrande;

        // Constructor
        public Sedan(string marca, string modelo, int numeroPortas, bool portaMalaGrande)
            : base(marca, modelo, numeroPortas)
        {
            this.portaMalaGrande = portaMalaGrande;
        }

        // Override mostrar method
        public override void mostrar()
        {
            base.mostrar();
            Console.WriteLine($"Sedan: Porta-malas Grande = {portaMalaGrande}");
        }

        // Override seguroParticular method if needed
        public new void seguroParticular()
        {
            Console.WriteLine("Seguro particular do sedan.");
        }
    }
}

using System;
using com.aluno.veiculos.entidades.veiculo;
using com.aluno.veiculos.entidades.servicos;

namespace com.aluno.veiculos.entidades.carros
{
    public class Carro : Veiculo, Seguro
    {
        // Private attribute
        private int numeroPortas;

        // Constructor
        public Carro(string marca, string modelo, int numeroPortas)
            : base(marca, modelo)
        {
            this.numeroPortas = numeroPortas;
        }

        // Override mostrar method
        public override void mostrar()
        {
            base.mostrar();
            Console.WriteLine($"Carro: Número de Portas = {numeroPortas}");
        }

        // Implement seguroParticular method
        public void seguroParticular()
        {
            Console.WriteLine("Seguro particular do carro.");
        }
    }
}

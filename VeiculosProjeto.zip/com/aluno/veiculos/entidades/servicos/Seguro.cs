namespace com.aluno.veiculos.entidades.servicos
{
    public interface Seguro
    {
        void seguroParticular();
    }
}

using System;

namespace com.aluno.veiculos.entidades.veiculo
{
    public class Veiculo
    {
        // Private attributes
        private string marca;
        private string modelo;

        // Constructor
        public Veiculo(string marca, string modelo)
        {
            this.marca = marca;
            this.modelo = modelo;
        }

        // Public virtual method
        public virtual void mostrar()
        {
            Console.WriteLine($"Veículo: Marca = {marca}, Modelo = {modelo}");
        }
    }
}

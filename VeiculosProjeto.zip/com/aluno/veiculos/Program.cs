using System;
using com.aluno.veiculos.entidades.veiculo;
using com.aluno.veiculos.entidades.carros;

namespace com.aluno.veiculos
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create Veiculo instances
            Veiculo veiculo1 = new Veiculo("Toyota", "Corolla");
            Veiculo veiculo2 = new Veiculo("Honda", "Civic");

            // Create Carro instances
            Carro carro1 = new Carro("Ford", "Fiesta", 4);
            Carro carro2 = new Carro("Chevrolet", "Cruze", 2);

            // Create Sedan instances
            Sedan sedan1 = new Sedan("BMW", "Serie 3", 4, true);
            Sedan sedan2 = new Sedan("Audi", "A4", 4, false);

            // Display Veiculo information
            veiculo1.mostrar();
            veiculo2.mostrar();

            // Display Carro information
            carro1.mostrar();
            carro2.mostrar();

            // Display Sedan information
            sedan1.mostrar();
            sedan2.mostrar();

            // Call seguroParticular method
            carro1.seguroParticular();
            carro2.seguroParticular();
            sedan1.seguroParticular();
            sedan2.seguroParticular();
        }
    }
}
